#!/bin/sh
ENV_FILE=$1
if [ -z $ENV_FILE ]; then
    echo 'env option is not given. exit...'
    exit 1;
else
    ENV_FILE='./env_files/local-env-tool/options/'$ENV_FILE
    echo $ENV_FILE' is given'
fi
if [ -f $ENV_FILE ]; then
    echo 'loading '$ENV_FILE
else
    echo $ENV_FILE' does not exist! Please make one following:'
    echo '==> https://nbhbank.atlassian.net/wiki/spaces/APPDEV/pages/757465097/Backend+Application+Setup#Step-7%3A'
    exit 1;
fi
node ./env_files/local-env-tool/localEnvLoader.js $ENV_FILE
# clearing TEST env variablew
export TEST=
source ./env_files/local-env-tool/exported
if [ -z $TEST ]; then 
    echo 'something is wrong. $TEST is not loaded from .env.local'
    exit 1;
else
    echo 'success!'
fi

