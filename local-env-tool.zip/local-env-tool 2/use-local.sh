#!/bin/bash

## Local Env Tool
## written by Song Jun (song.jun@nbhbank.com)
## copyright 2024
## this script is written to help to run Next.js web app to use proxy server on local environment.
##
## what it does:
## setting up .env.local based on environment that proxy server should use
## backup existing .env.local in case it has some option.
## give an instruction to run proxy tool

if [ $1 = '--help' ] || [ $1 = 'help' ] || [ -z $1 ]; then
    echo '==== local env tool help ===='
    echo 'run like this:'
    echo 'sh ./env_files/local-env-tool/use-local.sh {dev | qa | qa2}'
    exit 0;
fi

RUN_NOW=$2

echo 'checking valid folder'

if [ -d env_files/local-env-tool ]; then
    echo 'localenv exists'
else
    echo 'localenv does not exist. you should run it in the project root.'
    exit 1;
fi

echo 'checking template file'

TEMPLATE='./env_files/local-env-tool/template'

if [ -f $TEMPLATE ]; then
    echo 'template exists'
else
    echo 'template does not exist. it maybe not a valid structure.'
    exit 1;
fi

echo 'continue... now checking argument'

ENV=$1

if [ -z $ENV ]; then
    echo 'you should set argument.'
    echo 'possible options: dev | qa | qa2'
    echo 'i.e. use-local.sh dev'
    exit 1;
fi

echo 'continue... checking env source file to use'

ENV_SRC=./env_files/local-env-tool/options/$ENV

if [ -f $ENV_SRC ]; then
    echo $ENV_SRC' exists!'
else
    echo 'there is no '$ENV_SRC' file. creating one...'.
    cp $TEMPLATE $ENV_SRC
    echo 'please fill up environment source file before using.'
    echo 'after filling up, re-run it'
    exit 1
fi

echo 'continue... checking .env-temp'

if [ -d ~/.env-temp ]; then
    echo '~/.env-temp already exists!'
else
    echo '~/.env-temp does not exist. making one.'
    mkdir ~/.env-temp
fi

echo 'continue... now copying env to .env.local'

if [ -f .env.local ]; then
    NEW_NAME='saved.env.local.'$(date +"%Y%m%d_%H%M%S")

    echo 'existing .env.local will be moved to ~/.env-temp/'$NEW_NAME
    mv ./.env.local ~/.env-temp/$NEW_NAME

    if [ -f ~/.env-temp/$NEW_NAME ]; then
        echo 'moved properly. confirmed.'
    else
        echo 'cannot find the '$NEW_NAME' in the folder. something went wrong.'
        exit 1
    fi
else
    echo 'there is no .env.local file in your workspace.'
fi

echo 'continue... creating a new .env.local'

cp ./env_files/local-env-tool/options/$ENV ./.env.local

if [ -f .env.local ]; then
    echo '.env.local is installed properly. SUCCESS!'
else
    echo '.env.local is NOT installed properly. FAIL!'
    exit 1
fi

source ./env_files/local-env-tool/export-local.sh
