const fs = require('fs');
const dotenv = require('dotenv');
let file;
process.argv.forEach(function (val, index, array) {
    console.log(val, "index", index, )
    if(val.includes('localEnvLoader')){
        file = array[index + 1];
    };
});
console.log('selected file:', file)
if(!file){
    console.log("file should be given");
}else{
    const envs = dotenv.configDotenv({
        path: file
    })
    const parsed = envs.parsed;
    const shellVal = /^[0-9a-zA-Z_\.\/:]+$/
    const outputs = Object.keys(parsed).map(key=>{
        const val = parsed[key];
        const valToRet = shellVal.test(val).valueOf() ? val : `"${val}"`
        return `export ${key}=${valToRet}`;
    }).join('\n');
    fs.writeFileSync('./env_files/local-env-tool/exported', outputs, 'utf-8')
}